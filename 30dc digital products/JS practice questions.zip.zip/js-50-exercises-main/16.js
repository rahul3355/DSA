function doubleArrayElements(arr){
return arr.map( num=>  num *2 ) }

let arr = [10,20,30,40,50]
console.log(doubleArrayElements(arr))
console.log(arr);