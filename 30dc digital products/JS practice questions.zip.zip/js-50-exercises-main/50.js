function fraction(numerator,denominator){
const res = numerator/denominator;
return res.toString();
}

console.log(typeof fraction(1,2));