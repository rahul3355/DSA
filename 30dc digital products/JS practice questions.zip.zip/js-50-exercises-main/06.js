function checkEvenOrOdd(num){
    if(num % 2 == 0){
        return"Even";
    }
    else{
        return "Odd";
    }
}

console.log(checkEvenOrOdd(121))