let calculateAreaOfRectangle = (width,height) => {
    return width*height;
}

let area = calculateAreaOfRectangle(5,70);
console.log("Area of Rectangle is : " +area)