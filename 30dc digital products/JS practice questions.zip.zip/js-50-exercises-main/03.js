function addNumbers(a,b){
    return a+b;
}

console.log(addNumbers(5,10));