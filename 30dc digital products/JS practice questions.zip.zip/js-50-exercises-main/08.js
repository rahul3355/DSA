let arr = [20,30,40,10,8];

let sum = 0 ;
for(let i=0;i< arr.length;i++){
    sum+=arr[i];
}

console.log(sum);