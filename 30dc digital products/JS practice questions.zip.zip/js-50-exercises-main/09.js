let car = {
    make:"Toyota",
    model:"Camry",
    year:2022
}

car.startEngine = function(){
    console.log("Engine Started")
}

car.startEngine();