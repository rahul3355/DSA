# js-50-exercises

Unsolved Practice : https://docs.google.com/presentation/d/1ecbnYipUg2lDhgNvxUWB58i714avEJVRZEmHyafOhRs/edit?usp=sharing
