// console.log("Hello World");

let greet = "Hello World";
console.log(greet);