import React from 'react'

export default function One() {
  return (
    <div>
      Hello World !
    </div>
  )
}
