import React from 'react'

export default function Contact() {
  return (
    <div>
      CONTACT
    </div>
  )
}
